create
  definer = root@localhost procedure getrecord(IN in_id int, OUT out_name varchar(20), OUT out_age int)
BEGIN
  SELECT name,age
  into out_name,out_age
    FROM student  where id = in_id;
end;

